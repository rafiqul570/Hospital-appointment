<a <?php echo e($attributes->merge(['class' => 'block w-full px-4 py-2 text-left text-sm leading-5 text-gray-700 hover:bg-red-100 focus:outline-none focus:bg-gray-100 transition duration-150 ease-in-out'])); ?>><?php echo e($slot); ?></a>


<?php /**PATH D:\xampp\htdocs\Hospital-appointment\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>