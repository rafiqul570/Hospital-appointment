
<?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Shopping Cart</h2>
   
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item -> product_name); ?></td>
                        <td><?php echo e($item -> product_price); ?></td>
                        <td><?php echo e($item -> quantity); ?></td>
                        <td>$<?php echo e(number_format($item['product_price'] * $item['quantity'], 2)); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('remove.from.cart')); ?>">
                                <?php echo csrf_field(); ?>
                                
                                <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/front/pages/addToCard.blade.php ENDPATH**/ ?>