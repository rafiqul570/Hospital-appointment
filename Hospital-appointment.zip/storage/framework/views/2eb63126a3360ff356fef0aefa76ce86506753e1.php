<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Consultation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        nav{
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 20px;
        }

        #wellcome{
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 20px;
        }

       
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Consultation Booking</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <form action="<?php echo e(route('logout')); ?>"  method="POST">
                            <?php echo csrf_field(); ?>
                        <a class="nav-link text-light" href="<?php echo e(route('logout')); ?>">Log Out</a>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Booking Form -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
               <div class="card shadow p-3">
                <h3 class="text-center">Welcome to Our Hospital</h3>
                <p class="text-center">Book Your Consultation Appointment Online</p>
                <form>
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter your full name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter your email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" placeholder="Enter your phone number" required>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Preferred Date</label>
                        <input type="date" class="form-control" id="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Additional Notes</label>
                        <textarea class="form-control" id="message" rows="3" placeholder="Any additional information"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Book Appointment</button>
                </form>
            </div>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\Hospital-appointment\resources\views/pages/appointment.blade.php ENDPATH**/ ?>