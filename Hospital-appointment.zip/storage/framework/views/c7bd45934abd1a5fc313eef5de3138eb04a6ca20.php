<!-- ########## START: MAIN PANEL ########## -->
  <?php echo $__env->make('admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div class="sl-mainpanel">
      <div class="sl-pagebody">
        <div class="sl-page-title">
           
           <?php echo $__env->yieldContent('content'); ?>
        
        </div><!-- sl-page-title -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
     <?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- ########## END: MAIN PANEL ########## --><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/front/layouts/userProfileTemplate.blade.php ENDPATH**/ ?>