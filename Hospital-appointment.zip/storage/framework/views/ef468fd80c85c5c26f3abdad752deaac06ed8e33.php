
<?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<!-- Main contant Section-->

<div class="container">
    <h2 class="pt-5"><?php echo e($allCategory->category_name); ?> - (<?php echo e($allCategory->product_count); ?>)</h2>
   <div class="row my-5">
            <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="home" class="col-md-3">
                <div class="card shadow-sm">
                <a href="<?php echo e(route('front.pages.singlePage', [$data->id, $data->slug])); ?>"><img src="<?php echo e(asset('/uploads/image/'.$data->product_img)); ?>"></a>
                <p class="text-center"><?php echo e(Str::limit($data->product_name, 15)); ?></p><br>
                <h6 class="text-center"><span class="text-danger">price</span> $<?php echo e($data->product_price); ?></h6>
                <div class="d-flex justify-content-between mt-5">
                <button class="btn btn-dark"><a class="text-light" href="<?php echo e(route('front.pages.singlePage', [$data->id, $data->slug])); ?>">Buy Now</a></button>
                <button class="btn btn-warning"><a class="text-dark" href="<?php echo e(route('front.pages.singlePage', [$data->id, $data->slug])); ?>">See More</a></button>
                </div>
            </div>
           </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/front/pages/categoryPage.blade.php ENDPATH**/ ?>