
<?php $__env->startSection('content'); ?>


<h1>Wellcome <?php echo e(Auth::user()->name); ?></h1>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.userProfileTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/front/dashboard.blade.php ENDPATH**/ ?>