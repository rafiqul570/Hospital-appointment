   <?php
  $allCategory = App\Models\Category::latest()->get();      
  $allProduct = App\Models\Product::latest()->get();   
?> 

    <!-- Categories Section Begin -->
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                     <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="slaider" class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-1.jpg">
                            <h5><a href="<?php echo e(route('front.pages.singlePage', [$data->id, $data->slug])); ?>"><img class="mig1" src="<?php echo e(asset('/uploads/image/'.$data->product_img)); ?>"></a></h5>
                        </div>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>  
        </div>
    </section>
<!-- Categories Section End --><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/front/inc/slaider.blade.php ENDPATH**/ ?>