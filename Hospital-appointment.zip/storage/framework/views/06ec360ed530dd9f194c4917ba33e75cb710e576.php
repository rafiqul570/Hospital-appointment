
<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-lg-4">
                <div class="hero__categories">
                    <h3 class="deparment">Category & Subcategory</h3> 
                    <ul class="dropdown-menu1">
                    <?php $__currentLoopData = $allCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown"><a href="#"><?php echo e($data->category_name); ?><span>&rsaquo;</span></a>
                        <?php $subcats = \DB::table('subcategories')->where('category_id', $data->id)->get(); ?>
                        <ul class="dropdown-menu2">
                        <?php if($subcats): ?>
                        <?php $__currentLoopData = $subcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dropdown li1"><a href="<?php echo e(route('frontend.subcategoryPage', [$data->id, $data->slug])); ?>"><?php echo e($data->subcategory_name); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                        </li>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-8">
            <div class="card hero__categories">
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                    <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-img carousel-item <?php echo e($key == 0 ? 'active':''); ?>">
                        <?php if($data->product_img): ?>
                        <h3 class="text-center"><?php echo e($data->product_name); ?></h3>
                        <h6 class="text-center"><span class="text-danger">Price</span> : $<?php echo e($data->product_price); ?></h6>
                        <a href="<?php echo e(route('frontend.singlePage', [$data->id, $data->slug])); ?>"><img class="d-block w-100 img1" src="<?php echo e(asset('uploads/image/'.$data->product_img)); ?>">
                        </a>
                        <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                </div> 
            </div>
            </div>
            </div>
        </div>
    </div>
</section>
  <!-- Hero Section End -->

  
 <!-- Main contant Section-->

<div class="container">
    <div class="py-5"><h4>Categoris</h4></div>
    <div class="row">
            <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card card1">
                <a href="<?php echo e(route('frontend.singlePage', [$data->id, $data->slug])); ?>"><img class="mig1" src="<?php echo e(asset('/uploads/image/'.$data->product_img)); ?>"></a>
                <h5><?php echo e($data->product_name); ?></h5>
                <h6><?php echo e($data->product_price); ?></h6>
            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/frontend/homePage.blade.php ENDPATH**/ ?>