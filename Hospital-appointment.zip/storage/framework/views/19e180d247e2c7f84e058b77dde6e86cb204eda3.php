
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
</head>
<body>

    <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
      <div class="d-flex justify-content-between">
        <h3 class="text-dark pb-3">All Product</h3>
        <h5><a  href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-info text-light">Add Product</a></h5>
      </div>
        
         <div class="table-responsive">
           <table id="datatable1" class="table table-striped table-info">
             <thead>
               <tr>
                 <th class="wd-10p">SL</th>
                 <th class="wd-25p">Product Name</th>
                 <th class="wd-15p">Image</th>
                 <th class="wd-15p">action</th>
               </tr>
             </thead>

             <tbody>
                <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                 <td><?php echo e(++$key); ?></td>
                 <td><?php echo e($data->product_name); ?></td>
                 <td>
                  <img src="<?php echo e(asset('uploads/image/'.$data->product_img)); ?>" width="80" alt="">
                  <br>
                  <a class="btn btn-sm btn-primary mt-2" href="<?php echo e(route('admin.product.editImage', $data->id)); ?>">Update Image</a> 
                </td>
                
                 <td>
                    <a href="<?php echo e(route('admin.product.edit', $data->id)); ?>">Edit</a> ||
                    <a onclick="return confirm('Are you sure ?')" href="<?php echo e(route('admin.product.delete', $data->id)); ?>">Delete</a>
                 </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
          </table>
         </div>
       </div>

    <script src="https://code.jquery.com/jquery-3.7.1.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

    <script>
    <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    <?php endif; ?>
    </script>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom_laravel\resources\views/admin/product/index.blade.php ENDPATH**/ ?>