
<?php $__env->startSection('content'); ?>

<div class="card pd-20 pd-sm-40">
  <h6 class="card-body-title mb-5">Add New Category</h6>
  <div class="form-layout">
    <div class="row mg-b-25">
      <div class="col-lg-9">
        <form action="<?php echo e(route('category.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="form-control-label">Category name<span class="tx-danger">*</span></label>
            <input class="form-control" type="text" name="category" placeholder="" :value="old('category')" required autofocus autocomplete="category" />
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('category'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('category')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
          </div>
         </div><!-- col-4 -->
       </div><!-- row -->

      <div class="form-layout-footer">
     <button type="submit" class="btn btn-info mg-r-5">Add Category</button>
    </div><!-- form-layout-footer -->
   </form>
  </div><!-- form-layout -->
</div><!-- card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hospital-appointment\resources\views/category/create.blade.php ENDPATH**/ ?>