
<?php
  $patient = App\Models\Appointment::latest()->get();         
?>


<?php $__env->startSection('content'); ?>

 <div class="card pd-20 pd-sm-40">
        <h6 class="card-body-title">Book Your Consultation Online</h6>
        <p class="mg-b-20 mg-sm-b-30">Get expert advice from professionals anytime, anywhere.</p>

          <div class="table-wrapper">
            <table id="datatable" class="table table-striped" style="width:100%">
              <thead>
                <tr>
                  <th class="wd-10p">SL NO</th>
                  <th class="wd-10p">ID</th>
                  <th class="wd-20p">Patient name</th>
                  <th class="wd-20p">Phone number</th>
                  <th class="wd-20p">Doctor</th>
                  <th class="wd-10p">Date</th>
                  <th class="wd-10p">Action</th>
                </tr>
              </thead>
              
              <tbody>
              	<?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                  <td><?php echo e(++$key); ?></td>
                  <td><?php echo e($data->p_id); ?></td>
                  <td><?php echo e($data->p_name); ?></td>
                  <td><?php echo e($data->p_phone); ?></td>
                  <td><?php echo e($data->doctor); ?></td>
                  <td><?php echo e($data->date); ?></td>
                  <td>
                  	<a class="btn btn-primary" href="<?php echo e(route('appointment.delete', $data->id)); ?>">Delete</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->

      <?php $__env->stopSection(); ?>



       






      

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hospital-appointment\resources\views/appointment/index.blade.php ENDPATH**/ ?>