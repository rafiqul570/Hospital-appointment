<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Consultation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        nav{
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 20px;
        }

        #wellcome{
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 20px;
        }

       
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Consultation Booking</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                            <!-- Authentication -->
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();','style' => 'text-decoration: none; color: white;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();','style' => 'text-decoration: none; color: white;']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </form>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Booking Form -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
               <div class="card shadow p-3">
                <h3 class="text-center">Welcome to Our Hospital</h3>
                <p class="text-center">Book Your Consultation Appointment Online</p>
                <form action="appointment" method="POST">
                    <div class="mb-3">
                        
                        <input type="hidden" class="form-control" id="id" required value="<?php echo e(Auth::user()->id); ?>">
                        
                        <input type="hidden" class="form-control" id="name" required value="<?php echo e(Auth::user()->name); ?>">

                        <input type="hidden" class="form-control" id="phone" required value="<?php echo e(Auth::user()->phone); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name : <?php echo e(Auth::user()->name); ?></label>
                        
                    </div>
              
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number : <?php echo e(Auth::user()->phone); ?></label>
                       
                    </div>

                    <div class="mb-3">
                       <label for="phone" class="form-label">Select Doctor</label>
                       <select id="doctor" name="doctor" class="form-control" required>
                        <option value="Dr. John">Dr. John - Cardiologist</option>
                        <option value="Dr. Mary">Dr. Mary - Neurologist</option>
                        <option value="Dr. James">Dr. James - Orthopedic</option>
                      </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="date" class="form-label">Preferred Date</label>
                        <input type="date" class="form-control" id="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Additional Notes</label>
                        <textarea class="form-control" id="message" rows="3" placeholder="Any additional information"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Book Appointment</button>
                </form>
            </div>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\Hospital-appointment\resources\views/appointment.blade.php ENDPATH**/ ?>