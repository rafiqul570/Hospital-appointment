@extends('admin.layouts.template')

@section('content')

@include('appointment.index')

@endsection
